#ifndef BOOLEANS
#define BOOLEANS

//TRUE & FALSE VALUES FOR BETTER READABILITY
typedef enum {FALSE, TRUE} bool;

#endif