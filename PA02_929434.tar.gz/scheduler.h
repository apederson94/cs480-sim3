#include "dataStructures.h"

#ifndef SCHEDULER
#define SCHEDULER

int scheduleNext(struct PCB **pcbList, char *scheduler, int numProcesses);

#endif