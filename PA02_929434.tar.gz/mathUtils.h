#ifndef MATH_UTILS
#define MATH_UTILS

//ALL MATH UTILS

//RAISES AN INT BASE NUMBER TO A POWER AND RETURNS RESULT
float raiseToPower(int base, int power);

#endif